from django.shortcuts import render
from django.http import JsonResponse
from .models import Book
import random

def search_and_reserve_view(request):
    return render(request, 'books/mockup.html')

def ajax_search_book(request):
    if request.method == 'POST':
        query = request.POST.get('query', '').strip().lower()
        book = Book.objects.filter(
            book_id__iexact=query
        ).first() or Book.objects.filter(
            title__icontains=query
        ).first() or Book.objects.filter(
            author__icontains=query
        ).first()

        if book:
            return JsonResponse({
                'found': True,
                'book_id': book.book_id,
                'title': book.title,
                'author': book.author
            })
        else:
            return JsonResponse({'found': False})

def ajax_reserve_book(request):
    if request.method == 'POST':
        query = request.POST.get('book_id', '').strip().lower()
        book = Book.objects.filter(book_id__iexact=query).first() \
            or Book.objects.filter(title__icontains=query).first() \
            or Book.objects.filter(author__icontains=query).first()
        if not book:
            return JsonResponse({
                'success': False,
                'title': "Unknown",
                'author': "Unknown"
            })
        success = random.random() > 0.1
        return JsonResponse({
            'success': success,
            'title': book.title,
            'author': book.author
        })