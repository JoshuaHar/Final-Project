from django.urls import path
from . import views

urlpatterns = [
    path('', views.search_and_reserve_view, name='search'),
    path('ajax/search/', views.ajax_search_book, name='ajax_search'),
    path('ajax/reserve/', views.ajax_reserve_book, name='ajax_reserve'),
]